// Normalize country to standard ISO format
const normalizeCountry = (country) => {
    const countryMap = {
      'USA': 'US',
      'India': 'IN',
      'Germany': 'DE',
      // Add more mappings as necessary
    };
    return countryMap[country] || country;
  };
  
  // Normalize HS code to 6 digits (or adjust as necessary)
  const normalizeHSCode = (code) => {
    return code.trim().padStart(6, '0');
  };
  
  module.exports = { normalizeCountry, normalizeHSCode };
  