const Joi = require('joi');

const validateTariffRequest = (data) => {
  const schema = Joi.object({
    hsCode: Joi.string().length(6).pattern(/^\d+$/).required(), // HS Code is numeric and of length 6
    country: Joi.string().length(2).pattern(/^[A-Z]{2}$/).required(), // ISO 3166-1 alpha-2 country code
  });

  return schema.validate(data);
};

module.exports = { validateTariffRequest };
